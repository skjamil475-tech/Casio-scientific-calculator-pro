# Casio Scientific Calculator Pro

A responsive, installable scientific calculator PWA.

## Features
- Basic arithmetic, parentheses, powers, square root
- Trigonometric and inverse trigonometric functions
- DEG/RAD angle mode
- Logarithms, factorial, percentage, pi, e, and Ans
- Offline cache after the first successful visit

## Publish with GitHub Pages
1. Upload `index.html`, `manifest.webmanifest`, and `sw.js` to the repository root.
2. Open repository **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Choose branch **main**, folder **/(root)**, then **Save**.
5. Wait for deployment. The site URL will be shown in the Pages section.

Open the Pages URL in Safari on iPhone, tap Share, then **Add to Home Screen**.
